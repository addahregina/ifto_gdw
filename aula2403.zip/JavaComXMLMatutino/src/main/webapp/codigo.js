function ajax(recurso,mostrador)
{
    const xhr=new XMLHttpRequest();
    xhr.onreadystatechange=mostrador;
    xhr.open("get",recurso,true);
    xhr.send();
}
document.getElementById("btbuscarXML").onclick=function(evento){
    ajax("notacomdata.xml",function (){
        if(this.readyState==4 && this.status==200)
        {
            const docXML=this.responseXML;
            const de=docXML.getElementsByTagName("de")[0].firstChild.nodeValue;
            const para=docXML.getElementsByTagName("para")[0].firstChild.nodeValue;
            const cabecalho=docXML.getElementsByTagName("cabecalho")[0].firstChild.nodeValue;
            const corpo=docXML.getElementsByTagName("corpo")[0].firstChild.nodeValue;
            const datahora=docXML.getElementsByTagName("dataHora")[0].firstChild.nodeValue;

            const artigo=document.getElementById("artigo");
            const h2=artigo.getElementsByTagName("h2")[0];
            const spans=artigo.getElementsByTagName("span");
            const paragrafo2=artigo.getElementsByTagName("p")[1];
            const paragrafo3=artigo.getElementsByTagName("p")[2];
            spans[0].innerHTML=de;
            spans[1].innerHTML=para;
            h2.innerHTML=cabecalho;
            paragrafo2.innerHTML=corpo;
            paragrafo3.innerHTML=datahora;
        }
    });
}
