package aula.javacomxmlmatutino.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;

@WebServlet(name = "SerealizarNaString", value = "/SerealizarNaString")
public class SerealizarNaString extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/xml");
        response.setCharacterEncoding("utf-8");
        PrintWriter out=response.getWriter();
        String caminho=getServletContext().getRealPath("/WEB-INF/nota.xml");
        try {
            DocumentBuilderFactory fabrica=DocumentBuilderFactory.newInstance();
            DocumentBuilder construtor= fabrica.newDocumentBuilder();
            Document doc=construtor.parse(caminho);

            //adicionar a data no documento
            Element noData=doc.createElement("dataHora");
            Text noTexto=doc.createTextNode(LocalDateTime.now().toString());
            noData.appendChild(noTexto);
            doc.getDocumentElement().appendChild(noData);

            //serealizar e salvar
            TransformerFactory fabricaTransformador=TransformerFactory.newInstance();
            Transformer transformador=fabricaTransformador.newTransformer();
            DOMSource fonte=new DOMSource(doc);
            StringWriter escritor=new StringWriter();
            StreamResult resultado=new StreamResult(escritor);
            transformador.transform(fonte,resultado);
            String textoXml=escritor.toString();
            out.println(textoXml);

        } catch (Exception e) {
            out.print(e);
        }
    }
}
