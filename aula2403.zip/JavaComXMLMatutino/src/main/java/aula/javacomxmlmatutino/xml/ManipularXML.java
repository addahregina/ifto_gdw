package aula.javacomxmlmatutino.xml;

import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

public class ManipularXML {
    public ServletResponse inicializar(HttpServletResponse response, String path){
        response.setContentType("text/xml");
        response.setCharacterEncoding("utf-8");
        PrintWriter out=response.getWriter();
        return response;
    }
}