package aula.javacomxmlmatutino;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Teste", value = "/teste")
public class Teste extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String caminho=getServletContext().getRealPath("/WEB-INF/nota.xml");
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        out.println("<head><link rel='stylesheet' href='estilo.css'></head>");
        String local=request.getParameter("local");
        if(local==null)
            local="não informado";
        try {
            DocumentBuilderFactory fabrica=DocumentBuilderFactory.newInstance();
            DocumentBuilder construtor= fabrica.newDocumentBuilder();
            Document doc=construtor.parse(caminho);
            Element raiz=doc.getDocumentElement();

            //criar o local
            Element elementoLocal=doc.createElement("local");
            //Text noTexto=doc.createTextNode(local);
            elementoLocal.setTextContent(local);
            raiz.appendChild(elementoLocal);


            NodeList filhos=raiz.getChildNodes();
            int tam=filhos.getLength();
            //if(raiz.getAttributeNode("tipo").getNodeValue().equals("urgente"))
                out.print("<article class='"+raiz.getAttribute("tipo")+"'>");
            //else
                //out.print("<article>");
            for(int i=0;i<tam;i++)
            {
                Node filho= filhos.item(i);
                if(filho.getNodeType()==Element.ELEMENT_NODE) {
                    out.println("<p><b>" + filho.getNodeName());
                    out.println("</b>: "+filho.getFirstChild().getNodeValue()+"</p>");
                }
            }
            out.print("</article>");
        } catch (ParserConfigurationException | SAXException e) {
            out.println(e);
        }
    }
}
