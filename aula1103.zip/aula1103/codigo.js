function ajax(recurso,mostrador)
{
    const xhr=new XMLHttpRequest();
    xhr.onreadystatechange=mostrador;
    xhr.open("get",recurso,true);
    xhr.send();
}


function getAjaxContent(id){
    ajax("notas.xml",function (){
        if(this.readyState==4 && this.status==200)
        {
            const docXML=this.responseXML; 
            const totalNotas = docXML.getElementsByTagName("nota").length;                        

            if(id < totalNotas){   
                
                if(id== 0){
                    document.getElementById("btAnterior").style.display = 'none';
                } else {
                    document.getElementById("btAnterior").style.display = '';
                }

                const de=docXML.getElementsByTagName("de")[id].firstChild.nodeValue;
                const para=docXML.getElementsByTagName("para")[id].firstChild.nodeValue;
                const cabecalho=docXML.getElementsByTagName("cabecalho")[id].firstChild.nodeValue;
                const corpo=docXML.getElementsByTagName("corpo")[id].firstChild.nodeValue;

                const artigo=document.getElementById("artigo");
                const h2=artigo.getElementsByTagName("h2")[0];
                const spans=artigo.getElementsByTagName("span");
                const paragrafo2=artigo.getElementsByTagName("p")[1];
                spans[0].innerHTML=de;
                spans[1].innerHTML=para;
                h2.innerHTML=cabecalho;
                paragrafo2.innerHTML=corpo;
                artigo.setAttribute("artigo-id", id);

            } else {
                document.getElementById("btProximo").style.display = 'none';
                document.getElementById("btAnterior").style.display = '';
            
            }
            
        }
    }); 
}


function getAnterior(){
    let artigo_id=document.getElementById("artigo").getAttribute("artigo-id");
    artigo_id = artigo_id > 0 ? --artigo_id : 0;
    getAjaxContent(artigo_id);
}

function getProximo(){
    let artigo_id=document.getElementById("artigo").getAttribute("artigo-id");
    artigo_id++;
    getAjaxContent(artigo_id);
}

window.onload =function(evento){
    getAjaxContent(0);
}