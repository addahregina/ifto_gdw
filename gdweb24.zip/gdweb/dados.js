const livraria='<livraria>'+
'    <livro categoria="cooking" id="livro1">'+
		'<titulo lang="en">Everyday Italian</titulo>'+
		'<autor>Giada De Laurentiis</autor>'+
		'<ano>2005</ano>'+
		'<preco>30.00</preco>'+
	'</livro>'+
	'<livro categoria="children">'+
		'<titulo lang="en">Harry Potter</titulo>'+
		'<autor>J K. Rowling</autor>'+
		'<ano>2005</ano>'+
		'<preco>29.99</preco>'+
	'</livro>'+
	'<livro categoria="web">'+
		'<titulo lang="en">XQuery Kick Start</titulo>'+
		'<autor>James McGovern</autor>'+
		'<autor>Per Bothner</autor>'+
		'<autor>Kurt Cagle</autor>'+
		'<autor>James Linn</autor>'+
		'<autor>Vaidyanathan Nagarajan</autor>'+
		'<ano>2003</ano>'+
		'<preco>49.99</preco>'+
	'</livro>'+
	'<livro categoria="web" cover="paperback">'+
		'<titulo lang="en">Learning XML</titulo>'+
		'<autor>Erik T. Ray</autor>'+
		'<ano>2003</ano>'+
		'<preco>39.95</preco>'+
	'</livro>'+
'</livraria>';