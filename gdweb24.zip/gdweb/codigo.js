function pegaDocXML()
{
    livraria = localStorage.dados();
    if(livraria = null){
        livraria = "<livraria></livraria>"
    }
    const parser = new DOMParser();
    return parser.parseFromString(livraria,"text/xml");
}

function salvar(xmlDoc){
    let serializador = new XMLSerializer();
    let textoXML = serializador.serializeToString(xmlDoc);
    localStorage.dados = textoXML; 

}


function inserir(){
    let titulo= document.getElementById("titulo").value;
    let autor= document.getElementById("autor").value;
    let ano= document.getElementById("ano").value;
    let preco= document.getElementById("preco").value;
    
    let xmlDoc = pegaDocXML();

    let livro = xmlDoc.createElement("livro");

    criaElementoDoLivro("titulo", titulo, livro, xmlDoc);
    criaElementoDoLivro("autor",autor,livro, xmlDoc);
    criaElementoDoLivro("ano",ano,livro, xmlDoc);
    criaElementoDoLivro("preco",preco,livro, xmlDoc);

    /*
    let notitulo = xmlDoc.createElement("titulo");
    let noTextoTitulo = xmlDoc.createTextNode(titulo);
    notitulo.appendChild(noTextoTitulo);
    livro.appendChild
    */

    xmlDoc.documentElement.appendChild(livro);
    salvar(xmlDoc);
}

onload = function(){
    let aux = pegaDocXML()
    preencherTabela(aux);
}


let formatarParaBusca = (str) => str.replace(/( )/g, '').toLowerCase();

function pesquisar(pesquisa, dados) {
    pesquisa = formatarParaBusca(pesquisa);
    dados = formatarParaBusca(dados);
    return dados.search(pesquisa);
}

function preencherTabela(search, tag, xmlDoc){
    const raiz = xmlDoc.documentElement;
    const livros = raiz.getElementsByTagName("livro");
    let texto = "";
    for(let livro of livros)
        texto += livroParaTr(livro, search, tag);
    const corpo = document.querySelector("tbody");
    corpo.innerHTML = texto;
}

function livroParaTr(livro, search, tag) {
    let show = false;

    const titulo = pagaDadoDoLivro("titulo", livro);
    if(search && tag === 'titulo')
    show = pesquisar(search, titulo) < 0 ? show : true;
    
    const autor = pagaDadoDoLivro("autor", livro);
    if(search && tag === 'autor')
    show = pesquisar(search, autor) < 0 ? show : true;
    
    const ano = pagaDadoDoLivro("ano", livro);
    if(search && tag === 'ano')
    show = pesquisar(search, ano) < 0 ? show : true;
    
    const preco = pagaDadoDoLivro("preco", livro);
    if(search && tag === 'preco')
    show = pesquisar(search, preco) < 0 ? show : true;

    let tdline = `<tr>
    <td>${titulo}</td>
    <td>${autor}</td>
    <td>${ano}</td>
    <td>${preco}</td>
</tr>`;

    if(!search || show){
        return tdline;
    } else {
        return '';
    }
}

function createList (elements, properties){
    let list = '<ul>';
    for(let el of elements )
        list+= '<li>'+eval("el"+properties)+"</li>";
    list += '</ul>'; 
    return list;
}

//const preco = livro.getElementsByTagName("preco")[0].firstChild.nodeValue;
//let pagaDadoDoLivro = (tag, livro) => livro.getElementsByTagName(tag)[0].firstChild.nodeValue;
function pagaDadoDoLivro(tag,livro){
   const tags = livro.getElementsByTagName(tag);   
   
   if(tags.length > 1){
    return createList(tags,".firstChild.nodeValue");
   } else {
    return tags[0].firstChild.nodeValue;
   }
}

preencherTabela('', '', pegaDocXML());

let inputs = document.getElementsByClassName("filtro");
for(let input of inputs){
    input.addEventListener("keyup", function(e){
        preencherTabela(e.target.value, input.name, pegaDocXML());
    });
}

//let linha1 = document.querySelector("tbody").childNodes[1].setAttribute("class", "pink");
let linha1 = document.querySelector("tbody").childNodes[1];
linha1.childNodes[1].firstChild.nodeValue="Outro Livro";

td = linha1.childNodes[1];
td.setAttribute ("colspan", "2");

//append child
//insert before
//insert data insere diretamente no nodeavalue
//replace data
// localstorage

