function pegaDocXML()
{
    let livraria=localStorage.dados;
    if(livraria==undefined)
        livraria="<livraria></livraria>";
    const parser=new DOMParser();
    return parser.parseFromString(livraria,"text/xml");
}
function salvar(xmldoc)
{
    let serealizador=new XMLSerializer();
    let textoXML=serealizador.serializeToString(xmldoc);
    localStorage.dados=textoXML;
}
function pegaProximoSerial(){
    let novoId=localStorage.serial;
    if(novoId==undefined)
        novoId=1;
    else
        novoId++;
    localStorage.serial=novoId;
    return novoId;
}
function preencherTabela(search, tag, xmlDoc){
    const raiz = xmlDoc.documentElement;
    const livros=raiz.getElementsByTagName("livro");
    let texto="";
    /*for(let i=0;i<livros.length;i++)
        texto+=livroParaTr(livros[i]);*/
    for(let livro of livros)
        //@addah
        texto += livroParaTr(livro, search, tag);
        //texto+=livroParaTr(livro);
    const corpo=document.querySelector("tbody");
    corpo.innerHTML=texto;
}

//@addah
let formatarParaBusca = (str) => str.replace(/( )/g, '').toLowerCase();

//@addah
function pesquisar(pesquisa, dados) {
    pesquisa = formatarParaBusca(pesquisa);
    dados = formatarParaBusca(dados);
    return dados.search(pesquisa);
}


function livroParaTr(livro, search, tag)
{
    //@addah
    let show = false;

    //const titulo=livro.getElementsByTagName("titulo")[0].firstChild.nodeValue;
    const titulo=pegaDadoDoLivro("titulo",livro);
    //@addah
    if(search && tag === 'titulo')
    show = pesquisar(search, titulo) < 0 ? show : true;

    const autor=pegaDadoDoLivro("autor",livro);
    //@addah
    if(search && tag === 'autor')
    show = pesquisar(search, autor) < 0 ? show : true;

    const ano=pegaDadoDoLivro("ano",livro);
    //@addah
    if(search && tag === 'ano')
    show = pesquisar(search, ano) < 0 ? show : true;

    const categoria = pegaDadoDoLivro("categoria",livro);
    //@addah
    if(search && tag === 'categoria')
    show = pesquisar(search, categoria) < 0 ? show : true;

    
    const preco=pegaDadoDoLivro("preco",livro);
    //@addah
    if(search && tag === 'preco')
    show = pesquisar(search, preco) < 0 ? show : true;


    let tdline = `
    <tr class=${categoria}>
            <td>${titulo}</td>
            <td>${autor}</td>
            <td>${ano}</td>
            <td>${categoria}</td>
            <td>${preco}</td>
            <td><input onclick="remover(this.id)"  id="${livro.getAttribute("id")}" type="button" value="Deletar"></td>
        </tr>
        `;

    if(!search || show){
        return tdline;
    } else {
        return '';
    }
}

function buscarLivro(id,raiz)
{
    const livros=raiz.getElementsByTagName("livro");
    for(let livro of livros)
    {
        if(livro.getAttribute("id")==id)
            return livro;
    }
    return null;
}
function remover(id)
{
    //pegar o documento XML
    const xmlDoc=pegaDocXML();
    //pegar a raiz
    const raiz=xmlDoc.documentElement;

    //buscar o livro com o id especificado
    let livroParaRemover=buscarLivro(id,raiz);

    //remover da raiz o filho especificado
    if(livroParaRemover!=null)
    {
        raiz.removeChild(livroParaRemover);

        //salva
        salvar(xmlDoc);
        
        //redesenha a tela
        preencherTabela(xmlDoc);
    }
    else
        alert("Não foi possível remover");
}
//let pegaDadoDoLivro= (tag,livro) => livro.getElementsByTagName(tag)[0].firstChild.nodeValue;

function pegaDadoDoLivro(tag,livro){
    let tags=livro.getElementsByTagName(tag);
    if(tag=="autor"&&tags.length>1)
    {
        let texto="<ul>";
        for(let tag of tags)
            texto+=`<li>${tag.firstChild.nodeValue}</li>`
        return texto+"</ul>";
    }
    else
        return livro.getElementsByTagName(tag)[0].firstChild.nodeValue;
}

function criaElementoDoLivro(tag,texto,livro,xmlDoc)
{
    let elemento=xmlDoc.createElement(tag);
    let noTexto=xmlDoc.createTextNode(texto)
    elemento.appendChild(noTexto);
    livro.appendChild(elemento);
}

function inserir()
{
    //pegar os dados da interface
    let titulo=document.getElementById("titulo").value;
    let autores=document.querySelectorAll("#containerAutores>input[placeholder=Autor]");
    let ano=document.getElementById("ano").value;
    let e=document.getElementById("categoria");
    let categoria = e.options[e.selectedIndex].value;
    let preco=document.getElementById("preco").value;
    
    //pegar o documento XML
    let xmlDoc=pegaDocXML();
    
    //cria um novo livro com os dados da interface
    let livro=xmlDoc.createElement("livro");
    livro.setAttribute("id",pegaProximoSerial());
    criaElementoDoLivro("titulo",titulo,livro,xmlDoc);
    for(let autor of autores)
        criaElementoDoLivro("autor",autor.value,livro,xmlDoc);
    criaElementoDoLivro("ano",ano,livro,xmlDoc);
    criaElementoDoLivro("categoria",categoria,livro,xmlDoc);
    criaElementoDoLivro("preco",preco,livro,xmlDoc);

    //insere o livro no documento XML
    xmlDoc.documentElement.appendChild(livro);

    //salva
    salvar(xmlDoc);
    preencherTabela(xmlDoc);
    removerVariosInputsAutor();
}
function adicionaInputAutor(evento){
    const pai=document.getElementById("containerAutores");
    //const irmao=document.getElementById("btAdicionarAutor");
    const irmao=evento.target;
    const novoInput=document.createElement("input");
    novoInput.setAttribute("placeholder","Autor");
    novoInput.classList.add("extra"); //novoInput.setAttribute("class","extra");
    //novoInput.setAttribute("type","text");
    pai.insertBefore(novoInput,irmao);

}
function removerVariosInputsAutor(){
    const pai=document.getElementById("containerAutores");
    const inputs=document.querySelectorAll(".extra");
    const tam=inputs.length;
    for(i=tam-1;i>=0;i--)
    {
        pai.removeChild(inputs[i]);
    }
}


onload=function(){
    let aux=pegaDocXML()
    preencherTabela(aux)
    document.getElementById("botao").onclick=inserir;
    this.document.getElementById("btAdicionarAutor").addEventListener("click",adicionaInputAutor);
}
