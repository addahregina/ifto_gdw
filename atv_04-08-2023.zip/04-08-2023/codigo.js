onload=function(){
    let pai=this.document.getElementById("caixa");
    let ps=pai.getElementsByTagName("p");
    
   
   /* let i=0
    while(i<ps.length)
    {
        let p=ps[i]
        alert(p)
        i++
    }
   
   
    for(let i=0;i<ps.length;i++)
    {
        let p=ps[i]
        alert(p)
    }
 
    for(let i in ps)
    {
        alert(ps[i])
    }*/
    
    /*for(let p of ps)
        alert(p);*/

   /* let filhos=pai.childNodes;
    let tam=filhos.length;
    for(let i=0;i<tam;i++)
    {
        let filho=filhos[i];
        //if(filho.nodeType==1)
            alert(filho.nodeValue);
    }*/

    /*let filho=pai.firstChild; //filho=pai.childNodes[0]

    while(filho!=null)
    {
        alert(filho);
        filho=filho.nextSibling;
    }*/
    lista = pai.getElementsByTagName("p");
    const t= lista[1].lastChild.nodeValue;
    this.alert(t)

}