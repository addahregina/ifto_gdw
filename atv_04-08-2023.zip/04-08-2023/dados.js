const texto=`<livraria>
    <livro>
        <titulo>Livro de História</titulo>
        <autor>Carlos Gomes</autor>
        <ano>2020</ano>
        <preco>102</preco>
    </livro>
    <livro>
        <titulo>Livro de Geografia</titulo>
        <autor>Tadeu Silva</autor>
        <ano>2021</ano>
        <preco>90</preco>
    </livro>
    <livro>
        <titulo>Livro de Matématica</titulo>
        <autor>Maria Pereira</autor>
        <ano>2023</ano>
        <preco>150</preco>
    </livro>
</livraria>`;