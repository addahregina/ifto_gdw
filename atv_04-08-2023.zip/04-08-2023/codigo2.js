
document.getElementById("botao").onclick=function(){
    const parser=new DOMParser();
    const doc= parser.parseFromString(texto,"text/xml");
    const livros=doc.documentElement.getElementsByTagName("livro");

    let t = "";
    for(let livro of livros){

        const filhos=livro.childNodes;
        t+="<article>";
        for(let filho of filhos) {

            if(filho.nodeType==1)
            {
                let tag=filho.nodeName;
                let valor=filho.firstChild.nodeValue;
                t+=`<p><b>${tag}: </b>${valor}</p>`;

            }
        }
        t+="</article>";
    }
    document.getElementById("caixa").innerHTML=t;



    /*
    *
    *
    * */

}